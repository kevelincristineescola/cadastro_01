import hashlib

class SistemaAutenticacao:
    def __init__(self):
        # Dicionário para armazenar usuários: {nome_usuario: hash_senha}
        self._usuarios = {}

    def _gerar_hash_senha(self, senha: str) -> str:
        """Gera um hash SHA-256 da senha enviada."""
        return hashlib.sha256(senha.encode('utf-8')).hexdigest()

    def cadastrar_usuario(self, nome_usuario: str, senha: str) -> bool:
        """Cadastra um novo usuário no sistema."""
        nome_limpo = nome_usuario.strip().lower()
        
        if not nome_limpo or not senha:
            print("Erro: Nome de usuário e senha não podem estar vazios.")
            return False

        if nome_limpo in self._usuarios:
            print(f"Erro: O usuário '{nome_usuario}' já existe.")
            return False

        self._usuarios[nome_limpo] = self._gerar_hash_senha(senha)
        print(f"Sucesso: Usuário '{nome_usuario}' cadastrado!")
        return True

    def realizar_login(self, nome_usuario: str, senha: str) -> bool:
        """Autentica o usuário verificando o nome e a senha."""
        nome_limpo = nome_usuario.strip().lower()

        if nome_limpo not in self._usuarios:
            print("Erro: Usuário não encontrado.")
            return False

        hash_fornecido = self._gerar_hash_senha(senha)
        
        if self._usuarios[nome_limpo] == hash_fornecido:
            print(f"Bem-vindo(a), {nome_usuario}! Login realizado com sucesso.")
            return True
        else:
            print("Erro: Senha incorreta.")
            return False


# --- Teste do Sistema ---
if __name__ == "__main__":
    sistema = SistemaAutenticacao()

    # 1. Cadastrando usuários de teste
    print("--- CADASTRO ---")
    sistema.cadastrar_usuario("joao_silva", "SenhaSegura123")
    sistema.cadastrar_usuario("maria_loja", "MinhaLoja2026")
    
    # Tentativa de duplicado
    sistema.cadastrar_usuario("joao_silva", "outra_senha")

    # 2. Testando o Login
    print("\n--- LOGIN ---")
    sistema.realizar_login("joao_silva", "SenhaErrada")     # Senha incorreta
    sistema.realizar_login("joao_silva", "SenhaSegura123") # Sucesso
    sistema.realizar_login("admin", "1234")               # Usuário inexistente
